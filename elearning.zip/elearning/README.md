This assesment was developed on node V9.10.0 and npm V5.6.0. If you have any difficulties to run the app, Please update spicific versions to your node & npm.

## Libraries used for assesment

| Type      | Library |
| :-------- | :------ |
| Front-End | React   |
| Back-End  | Express |
| Database  | lowdb   |

## Commands to run the app

```sh
npm install
npm run dev
```
